Included in my final project are 3 .txt files that hold my implementation for each the 6 pipeline and 2 pipeline adders named accordingly.
The 3rd file is the test bench which shouldn't be needed but I added for backup. 
To test each just copy paste the .txt files into the file called "pipelined_adder". The file that is pre-loaded is the 2pipeline design including the delays
for this file  preset in the test bench file. When you want to test the 6pipeline design, copy paste the 6bit6pipeline.txt file into the pipelined_adder
file and change the delays on the test bench accordingly. Descriptions of the delays are in the word file included with the project submission.
If there are any questions or concerns please let me know at morelock.4@wright.edu. 